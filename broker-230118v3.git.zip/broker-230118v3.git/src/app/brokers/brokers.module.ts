// import { BrokersModel } from './brokers.model';
import { AppComponent } from './../app.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgModel, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule, Title } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { BrokersComponent } from './brokers.component';
import { BrokersService } from './brokers.service';
import { BrokersInclusaoComponent } from './brokers-inclusao/brokers-inclusao.component';
import { BrokersRoutingModule } from './brokers-inclusao/brokers-router';

@NgModule({
  declarations: [
    BrokersComponent,
    BrokersInclusaoComponent
],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    AngularFontAwesomeModule,
    FormsModule,
    BrokersRoutingModule,
//    BrokersModel,
    HttpClientModule
  ],
  providers: [
    Title,
    BrokersService,
//    BrokersModel
  ],
  bootstrap: []
})
export class BrokersModule { }
