import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brokers-inclusao',
  templateUrl: './brokers-inclusao.component.html',
  styleUrls: ['./brokers-inclusao.component.css']
})
export class BrokersInclusaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

console.log('----------> brokers inclusao');
