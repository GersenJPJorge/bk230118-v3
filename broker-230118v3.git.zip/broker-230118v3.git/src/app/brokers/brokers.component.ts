import { Component, OnInit } from '@angular/core';
import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Usuario } from './../pages/login/usuario';
import { TokenService } from './../services/token.service';
import { BrokersService } from '../brokers/brokers.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-brokers',
  templateUrl: './brokers.component.html',
  styleUrls: ['./brokers.component.css'],
  providers: [Usuario]
})

@Injectable()
export class BrokersComponent implements OnInit {

  constructor(private usuario: Usuario, public token: TokenService, private http: HttpClient, public brokers: BrokersService) { }

  ngOnInit() {

    console.log('usertoken', this.token.userToken)

    const urlGetCompany ='https://172.18.195.10:5601/v1/broker';
    let headersParam = new HttpHeaders();
    headersParam = headersParam.set('Content-Type', 'application/json');
    headersParam = headersParam.set('Authorization', 'Bearer ' + this.token.userToken);
    headersParam = headersParam.set('environmentName', 'hml');
    headersParam = headersParam.set('systemName', 'cadu');
    headersParam = headersParam.set('productName', 'webCadu');
    headersParam = headersParam.set('companyName', 'cadu');

    console.log('----------------------> acesso headers param', headersParam);
    this.http.get(urlGetCompany, {
        headers: headersParam
          })
    .subscribe(
      data => {
          this.brokers = data['listBroker'];
        console.log('----------------------> acesso broker', data);
      },
      error => {
        console.log('Erro. Se persistir, entre em contato com o suporte técnico.', error);
      }
    );
  }

  // Função para inserir uma broker
  incluiBroker() {
    console.log('incluiBroker');
  }

  // Função para editar uma broker
  editaBroker() {
    console.log('editaBroker');
  }

  // Função para excluir uma broker
  excluiBroker() {
    console.log('excluiBroker');
  }

}
