import { BrokersInclusaoComponent } from './brokers-inclusao.component';
import { RouterModule, Routes} from '@angular/router'
import { AuthGuard } from './../../guards/auth-guard';
import { BrokersComponent } from './../brokers.component';

const BrokersRoutes: Routes = [
   {
    path: 'inclusao',
    component: BrokersInclusaoComponent,
    canActivate: [AuthGuard],
//    data: {title: 'Brokers Inclusão'}
    },
//  {
//    path: '',
//    component: BrokersComponent,
//    canActivate: [AuthGuard],
//    data: {title: 'Brokers'}
//},
// {
//  path: 'brokers',
//  component: BrokersComponent,
//  canActivate: [AuthGuard],
//  data: {title: 'Brokers'}
// },
];

export const BrokersRoutingModule = RouterModule.forChild(BrokersRoutes);
